<?php

namespace App;

class Newdatabase extends model
{

    protected $garded = [];

    protected $table = "newdatabase";

}
